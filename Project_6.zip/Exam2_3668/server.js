var express = require('express');
var app = express();
const bodyParser  = require('body-parser');

const axios = require('axios');
// set the view engine to ejs

app.use(bodyParser.urlencoded());

app.set('view engine', 'ejs');


// use res.render to load up an ejs view file

// index page
app.get('/', function(req, res) {

  res.render('pages/index', {
    
  });
});

app.get('/shoppingcart', function(req, res) {
    axios.get('https://dummyjson.com/carts')
    .then((response)=> {
        // calculate cart averages and store them in an array
        const carts = response.data.carts;
        const cartAverages = [];
        for (let i = 0; i < carts.length; i++) {
            let total = 0;
            let quantity = 0;
            for (let j = 0; j < carts[i].products.length; j++) {
                total += carts[i].products[j].price * carts[i].products[j].quantity;
                quantity += carts[i].products[j].quantity;
            }
            const average = total / quantity;
            cartAverages.push({
                id: carts[i].id,
                average: average.toFixed(2)
            });
        }
        res.render('pages/shoppingcart', {cartAverages}); });
    
    });

app.listen(6060);
console.log('Server is listening on port 6060');