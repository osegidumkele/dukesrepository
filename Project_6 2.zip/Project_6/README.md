Hello, thanks for downloading and checking out my product
install node and ejs and exios depedencies first
-npm install
-npm install axios
-install ejs@4.1.7
run at localhost 6060 or desired port